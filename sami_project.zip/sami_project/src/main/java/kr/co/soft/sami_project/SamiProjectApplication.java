package kr.co.soft.sami_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamiProjectApplication.class, args);
	}

}
