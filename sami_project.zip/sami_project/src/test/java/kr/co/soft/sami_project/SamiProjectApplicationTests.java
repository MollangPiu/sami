package kr.co.soft.sami_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
